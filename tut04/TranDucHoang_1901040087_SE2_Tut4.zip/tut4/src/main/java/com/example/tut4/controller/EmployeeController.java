package com.example.tut4.controller;

import com.example.tut4.model.Employee;
import com.example.tut4.model.User;
import com.example.tut4.repository.EmployeeRepository;
import com.example.tut4.repository.UserRepository;
import com.example.tut4.service.CustomUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

// TODO: check validation of user (partly ok )
//  add list of users
//  change index page
//  update image by local file



@Controller
public class EmployeeController {
    @Autowired
    EmployeeRepository employeeRepository;

    @Autowired
    CustomUserDetailsService userDetailsService;

    @RequestMapping(value = "/list")
    public String getAllEmployee(Model model) {
        List<Employee> employees = employeeRepository.findAll();
        model.addAttribute("employees", employees);
        return "employeeList";
    }

    @GetMapping(value = "/login")
    public String login() {
        return "login";
    }

    @GetMapping(value = "/registration")
    public String registration(Model model){
        model.addAttribute("user", new User());
        return "registration";
    }

    @PostMapping(value = "registration")
    public String signUp(@Valid User user, BindingResult result){
        if(result.hasErrors()) return "registration";

//        encode password
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        String encodedPassword = encoder.encode(user.getPassword());
        user.setPassword(encodedPassword);
        user.setRole("ROLE_USER");

        userDetailsService.createUser(user);
        return "registrationProcess";
    }

    @RequestMapping(value = "/{id}")
    public String getEmployeeById(
            @PathVariable(value = "id") Long id, Model model) {
        Employee employee = employeeRepository.getById(id);
        model.addAttribute("employee", employee);
        return "employeeDetail";
    }

    @RequestMapping(value = "/add")
    public String addEmployee(Model model) {
        Employee employee = new Employee();
        model.addAttribute("employee", employee);
        return "employeeAdd";
    }

    @RequestMapping(value = "/update/{id}")
    public String updateEmployee(
            @PathVariable(value = "id") Long id, Model model) {
        Employee employee = employeeRepository.getById(id);
        model.addAttribute(employee);
        return "employeeUpdate";
    }

    @RequestMapping(value = "/save")
    public String saveUpdate(
            @RequestParam(value = "id", required = false) Long id, @Valid Employee employee, BindingResult result) {

        if(result.hasErrors()){
            return (id == null) ? "employeeAdd" : "employeeUpdate";
        }

        employee.setId(id);


        employeeRepository.save(employee);

//        redirect id for generate ID
        String empPhone = employee.getPhone();
        Employee addedEmployee = employeeRepository.findByPhone(empPhone);
        Long newId = addedEmployee.getId();
        return "redirect:/genid/" + newId;
    }

    @GetMapping(value = "/genid/{id}")
    public String setId(@PathVariable(value = "id")Long id){
        Employee employee = employeeRepository.getById(id);
        //        generate empId
        String empId = employee.getEmpId();
        if (empId == null){
            empId = generateEmpId(employee);
        }
//        set default image
        if (employee.getImage().equals("")){
            employee.setImage("/image/default_user_image.png");
        }

        employee.setEmpId(empId);
        employeeRepository.save(employee);
        return "redirect:/list";
    }


    @RequestMapping(value = "/delete/{id}")
    public String deleteEmployee(
            @PathVariable(value = "id") Long id) {
        Employee employee = employeeRepository.getById(id);
        employeeRepository.delete(employee);
        return "redirect:/list";
    }

    @GetMapping(value = "/403")
    public String forbidden(){
        return "403";
    }

//    OTHER FUNCTIONS

/**
 * format: DDYYGGXXXX
 * DD  -  Department short
 * YY  -  Join date
 * GG  -  Gender
 * X   -  Auto generated depend on id
 * */
    private String generateEmpId(Employee employee){
        int id = Integer.valueOf(employee.getId().intValue());
        char gender = employee.getGender();
        String department = employee.getDepartment(),
                joinDate = employee.getJoinDate().substring(2,4),
                empId = "",
                genderInt = (gender == 'm') ? "01" : "02";

//        add department
        String[] departmentArr = department.split(" ");
        if(departmentArr.length == 1){
            empId += departmentArr[0].charAt(0) + "0";
        } else {
            for (String s : departmentArr) {
                empId += s.charAt(0);
            }
        }

//        add remain properties
        empId += joinDate + genderInt + String.format("%04d",id);

        return empId;
    }
}



