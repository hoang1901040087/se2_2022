package com.example.tut4;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

public class PasswordEncoder {
    public static void main(String[] args) {
//        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
//        String rawpass = "apassword";
//        String encodedPass = encoder.encode(rawpass);
//
//        System.out.println(encodedPass);

//        Long l = 123L;
//        int i = l.intValue();
//        System.out.println(String.format("%05d",l));
//        int id = 1;
//        String department = "Marketing",
//                joinDate = "2021-05-23", genderInt;
//        char gender = 'm';
//        String empId = "";
//
//        String[] sArr = department.split(" ");
//        if(sArr.length == 1){
//            empId += sArr[0].charAt(0) + "0";
//        } else {
//            for ( String s : sArr) {
//                empId += s.charAt(0);
//            }
//        }
//
//
//        empId += joinDate.substring(2,4);
//        genderInt = (gender == 'm') ? "01" : "02";
//        empId += genderInt;
//        String last = String.format("%04d",id);
//        empId += last;
//
//        System.out.println(empId);
//        Long l = 1L;
//        int id = Integer.valueOf(l.intValue());
//        System.out.println((Object)  );
}
}
