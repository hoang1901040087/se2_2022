package com.example.tut4.model;

import org.hibernate.validator.constraints.Length;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "employee")
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @NotEmpty
    @Length(min = 2, max = 30)
    @Column(name = "first_name", nullable = false, length = 30)
    private String firstName;

    @NotEmpty
    @Length(min = 2, max = 30)
    @Column(name = "last_name", nullable = false, length = 30)
    private String lastName;

    @NotEmpty
    @NotNull
    @Column(name = "email", nullable = false, length = 128)
    private String email;

    @Column(name = "image", nullable = true, length = 255)
    private String image;

    @NotEmpty(message = "Invalid address")
    @Column(name = "address", nullable = false, length = 255)
    private String address;

    @Length(min = 10, max = 15)
    @Column(name = "phone", nullable = false, length = 15)
    private String phone;

    @NotEmpty
    @NotNull
    @Column(name = "dob", nullable = false)
    private String dob;

    @NotEmpty
    @NotNull
    @Column(name = "join_date", nullable = false)
    private String joinDate;

    @NotNull
    @Column(name = "gender", nullable = false, length = 1)
    private char gender;

    @NotEmpty
    @NotNull
    @Column(name = "department", nullable = false, length = 64)
    private String department;

    @NotEmpty
    @NotNull
    @Column(name = "position", nullable = false, length = 100)
    private String position;

    //    auto generate by fn
    @Column(name = "emp_id", nullable = true, length = 15)
    private String empId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDoB() {
        return dob;
    }

    public void setDoB(String doB) {
        dob = doB;
    }

    public String getJoinDate() {
        return joinDate;
    }

    public void setJoinDate(String joinDate) {
        this.joinDate = joinDate;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public String getFullName() {
        return String.format("%s %s", firstName, lastName);
    }

    /** su dung
     * doc du lieu dau vao tu exel
     *  hoi nhom cu ve problem desc
     *  ==> xac dinh set
     *  */
}



