package com.example.tut4.repository;


import com.example.tut4.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    @Query("select e from Employee e where e.phone = ?1")
    Employee findByPhone(String phone);
}