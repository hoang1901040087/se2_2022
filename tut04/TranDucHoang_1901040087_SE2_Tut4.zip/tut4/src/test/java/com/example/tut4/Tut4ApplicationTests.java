package com.example.tut4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tut4ApplicationTests {

    @Test
    void contextLoads() {
    }

}
