package com.example.tut4;

import static org.assertj.core.api.Assertions.assertThat;

import com.example.tut4.model.Employee;
import com.example.tut4.model.User;
import com.example.tut4.repository.EmployeeRepository;
import com.example.tut4.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback(false)
public class UserRepositoryTest {
    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private EmployeeRepository repo;

    @Test
    public void testCreateUser(){
//        User user = new User();
//        user.setUsername("test1");
//        user.setPassword("123456");

        Employee emp = new Employee();
        emp.setFirstName("Tran");
        emp.setLastName("Van A");
//        emp.setAge(30);
        emp.setDepartment("IT");
        emp.setEmpId("1111");
        emp.setAddress("hanoi");
        emp.setGender('m');
        emp.setDoB("1990-10-23");
        emp.setPhone("84123456789");
        emp.setJoinDate("2019-12-5");

        Employee savedEmp = repo.save(emp);

        Employee existEmp = entityManager.find(Employee.class, savedEmp.getId());

        assertThat(emp.getFullName()).isEqualTo(existEmp.getFullName());
    }
}
